#include "types.h"
#include "stat.h"
#include "user.h"


int main(){
/*
   int count = 0;
   int pid;
   
   if( ! (pid = fork())){
	while((count < 2) && (pid = fork())){
		count++;
		printf(1, "First while loop");
	}
	if(count > 0){
	   printf(1, "Inside the if count > 0");
	}
}
   if(pid){
	waitpid(pid,0, 0);
	count = count << 1;
	printf(1, "inside if pid");
	}*/
printf("\n\n asdlkasjdaslkdjasdl \n\n");
procdump();
return 0;
}
